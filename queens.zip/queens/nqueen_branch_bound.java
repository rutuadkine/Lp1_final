import java.util.*;

public class nqueen{

	int matrix[][] = new int[4][4];
	
	class Position{
	int row;
	int col;
	Position(int row,int col)
	{
	this.row=row;
	this.col=col;
	}

	}

	public Position[] solveNQueen(int n)
	{
		Position[] positions=new Position[n];
		boolean hasSolution=solveNQueen2(n,0,positions);
		if(hasSolution)
		{
			// for(int i=0;i<n;i++)
			// {
			// 	System.out.print(positions[i].row);
			// }

			for(int i=0;i<4;i++) {
				for(int j=0;j<4;j++) {
					System.out.print(matrix[i][j] + " ");
				}
				System.out.print("\n");
			}
			return positions;

		}
		else
		{
			return new Position[0];
		}
	}

	public boolean solveNQueen2(int n,int row,Position[] positions)
	{
		if(n==row)
		{
			return true;
		}
		int col;
		for(col=0;col<n;col++)
		{
			boolean foundSafe=true;
			for(int queen=0;queen<row;queen++)
			{
				if(positions[queen].col==col || positions[queen].row-positions[queen].col==row-col || positions[queen].row+positions[queen].col==row+col)
				{
					foundSafe=false;
					break;
				}
			}
			if(foundSafe)
			{
				positions[row]=new Position(row,col);
				if(solveNQueen2(n,row+1,positions)){
					
					matrix[row][col]=1;
					return true;

				}
			}
		}

		return false;
	}

	public static void main(String[] args)
	{
		nqueen nq= new nqueen();
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.print("\nEnter n");
		n=sc.nextInt();
		Position[] pos=new Position[n];
		pos=nq.solveNQueen(n);

		

	}


}