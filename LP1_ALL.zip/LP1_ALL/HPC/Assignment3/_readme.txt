1)save both files in same folder(recommended)

2)Commands for windows

A1)g++ SerialBubbleSort.cpp -lgomp -o a.exe

A2)a.exe

B1)g++ parallelBubbleSort.cpp -lgomp -o a1.exe

B2)a1.exe