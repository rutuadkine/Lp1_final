class operation:
    def __init__(self,op_name,operand1,operand2):
        self.op_name = op_name
        self.operand1 = operand1
        self.operand2 = operand2

