back_track.java file contains logic for branch and bound. Don't get confused with file name.

queen.java contains logic for backtracking.