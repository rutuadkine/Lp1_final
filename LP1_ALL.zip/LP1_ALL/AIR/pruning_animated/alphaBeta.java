package pruning;

public class alphaBeta {

   
    int return_height(int n)
    {
        if(n==1)
            return 0;


        else
            return 1+return_height(n/2);
    }

    public static void main(String[] args) {

        System.out.println("For alpha beta");
        int scores[]={3, 5, 6,9,1,2,0,-1};

        alphaBeta ab = new alphaBeta();
        int height = ab.return_height(scores.length);

        

        thread2 th2 = new thread2(scores,height);
        th2.start();


    }


}
