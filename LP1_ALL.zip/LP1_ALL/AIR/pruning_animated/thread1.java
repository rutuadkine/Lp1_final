package pruning;

public class thread1 extends Thread{
    display d;
    int[] scores;
    int height;

    thread1(int[] scores,int height)
    {
        this.scores=scores;
        this.height=height;

        d = new display();
        d.add_elements(scores,height);
    }
    public void run(){
        try {
           int result =  minMax(0,0,true,this.scores,height);
            d.setRoot(result);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public int minMax(int depth,int nodeNo,boolean isMax,int scores[],int h) throws InterruptedException {

        if(depth == h) {

            // System.out.println("currently evaluating node"+nodeNo);
            d.setColor(nodeNo);
            this.sleep(2000);
            return scores[nodeNo];
        }

        else if(isMax) {
            int ans = Math.max(minMax(depth + 1, nodeNo * 2, false, scores, h), minMax(depth + 1, nodeNo * 2 + 1, false, scores, h));
            //System.out.println("ans returned in isMax @ depth = "+ans+" "+depth);
            //System.out.println("node1 = "+(nodeNo*2)+" and node2 = "+(nodeNo*2+1));
            d.setText(ans,depth,nodeNo*2,nodeNo*2+1);
            this.sleep(2000);
            return ans;
        }
        else {
            int ans = Math.min(minMax(depth + 1, nodeNo * 2, true, scores, h), minMax(depth + 1, nodeNo * 2 + 1, true, scores, h));
            //System.out.println("ans returned in isNOTMax @ depth = "+ans+" "+depth);
            //System.out.println("node1 = "+(nodeNo*2)+" and node2 = "+(nodeNo*2+1));
            d.setText(ans,depth,nodeNo*2,nodeNo*2+1);
            this.sleep(2000);
            return ans;
        }

    }
}
