
public class InitiateAlgorithm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GoalStackAlgorithm goalStackAlgorithm = new GoalStackAlgorithm();
		goalStackAlgorithm.acceptGoalState();
		goalStackAlgorithm.acceptInitialState();
		goalStackAlgorithm.displayGoalState();
		goalStackAlgorithm.displayStates();
		goalStackAlgorithm.algorithm();
	}

}
