#include<bits/stdc++.h>
#include<chrono>
#include "tree.hpp"

#define clock_now chrono::high_resolution_clock::now
#define duration chrono::duration_cast<chrono::microseconds>


using namespace std;

void bfs(node* root)
{
	queue<node*>q;
	q.push(root);
	node*c;

	while(!q.empty())
	{
		c=q.front();
		q.pop();
		if(c->left!=NULL)
			q.push(c->left);
		if(c->right!=NULL)
		{
			q.push(c->right);
		}
	}


}

void parallelBfs(node *root)
{
	queue<node*>q;
	q.push(root);
	node*c;
	/*#pragma omp parallel sections
	{
		while(!q.empty()){
		c=q.front();
		q.pop();
	#pragma omp section
	{
		if(c->left!=NULL)
		{
			q.push(c->left);
		}
	}

	#pragma omp section
	{
		if(c->left!=NULL)
		{
			q.push(c->left);
		}
	}
}*/
#pragma omp parallel sections
		{
			while(!q.empty()){
		c=q.front();
		q.pop();
#pragma omp section
			{
				if(c->left!=NULL)
		{
			q.push(c->left);
		}
			}
#pragma omp section
			{
				if(c->left!=NULL)
		{
			q.push(c->left);
		}
				
			}

		}
	}
}

int main()
{
	tree t;
	auto start=clock_now();

	for(int i=0;i<500;i++)
	{
		t.addNode(rand());
	}

	auto end=clock_now();
	auto time=duration(end-start);
	cout << "For filling the tree: " << time.count() << " microseconds" << endl;

	start=clock_now();
	bfs(t.returnRoot());
	end=clock_now();

	time=duration(end-start);

	cout << "For serial bfs: " << time.count() << " microseconds" << endl;

	start=clock_now();
	parallelBfs(t.returnRoot());
	end=clock_now();

	time=duration(end-start);

	cout << "For parallel bfs: " << time.count() << " microseconds" << endl;
	return 0;
	
	

}



